import { LightningElement,track,api} from 'lwc';
import businessSalesMap from '@salesforce/apex/BusinessSales.businessSalesMap';

export default class salesTotal extends LightningElement {
    @api region;
    @api salesList;
    @track salesValue;
    error;
    
    connectedCallback() {
        businessSalesMap({
           region: this.region, 
           salesList: this.salesList 
        })
        .then(result => {
             this.salesValue = result;
        }).catch(error=>{
            this.error = error;
            this.emplist = undefined;
        })
    }
}