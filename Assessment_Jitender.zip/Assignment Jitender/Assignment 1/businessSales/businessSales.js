import { LightningElement,wire,track } from 'lwc';
import businessSalesMethod from '@salesforce/apex/BusinessSales.businessSalesMethod';
export default class TryGrouping extends LightningElement {
	
    @track salesList = [];   //Get list of business records
	error;


   connectedCallback() { 
		this.businessSalesResult();
	}
    
    businessSalesResult(){
	businessSalesMethod({
        city1: 'Delhi', 
        city2 : 'Mumbai'
     })
    .then(result => {
            this.salesList = result;
           // alert('salesList'+this.salesList);
        })
        .catch(error => {
            this.error = error;
        });
    }
     
    get saleArray() {
		
		//Map for mapping based on region
       let groupedDataMap = new Map();
       this.salesList.forEach(sale => {
           if (groupedDataMap.has(sale.Operating_Region__c)) {
               groupedDataMap.get(sale.Operating_Region__c).sales.push(sale);
           } else {
               let newSale = {};
               newSale.Operating_Region__c = sale.Operating_Region__c;
               newSale.sales = [sale];
               groupedDataMap.set(sale.Operating_Region__c, newSale);
           }
       });

       let itr = groupedDataMap.values();
       let saleArray = [];
       let result = itr.next();
       while (!result.done) {
		   //Get length for row merge based on Operating Region
           result.value.rowspan = result.value.sales.length + 1;
           saleArray.push(result.value);
           result = itr.next();
       }
       return saleArray;
   }
}