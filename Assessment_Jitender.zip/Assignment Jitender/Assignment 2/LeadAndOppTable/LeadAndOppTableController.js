({
    loadData: function (component, event, helper) {
        component.set('v.columns', [
            {label: 'Owner Id', fieldName: 'ownerId', type: 'text'},
            {label: 'Owner Name', fieldName: 'ownerName', type: 'text'},
			{label: 'Total Leads', fieldName: 'leadTotal', type: 'number'},    
            {label: 'Total Opportunities', fieldName: 'oppTotal', type: 'number'},
            {label: 'Latest Created Date(Opp)', fieldName: 'oppDate', type: 'date'},
            {label: 'Total Val(Opp)', fieldName: 'oppAmount', type: 'currency'}
        ]);
        var action = component.get('c.leadAndOppsMethod');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                component.set("v.data", response.getReturnValue());
            }
            else if(state === "INCOMPLETE"){
        
            }
            else if(state === "ERROR"){
                var errors = response.getError();
                if(errors){
                    if(errors[0] && errors[0].message){
                        console.log("Error message: " + errors[0].message);
                    }
                }else{
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    }
});